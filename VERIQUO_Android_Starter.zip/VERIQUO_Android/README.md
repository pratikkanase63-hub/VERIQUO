# VERIQUO Android starter

A native Android starter app using Kotlin and Jetpack Compose. It includes a premium dark visual theme, bottom navigation, sample feed, story placeholders, like/save interactions, Explore search field, Create draft screen, Reels placeholder, and Profile screen.

## Open and run
1. Install Android Studio (latest stable).
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `VERIQUO_Android` folder.
4. Allow Gradle sync and install the Android SDK 35 if prompted.
5. Run on an Android emulator or a phone with USB debugging enabled.

## Important current limitations
This is a front-end starter, not a production social network or APK. Demo posts are local sample data. Login, real accounts, server-side feed, photo/video uploads, messaging, notifications, moderation, and secure storage are not connected yet.

## Suggested next backend stage
Connect Firebase Authentication, Cloud Firestore, Cloud Storage, and Firebase Cloud Messaging. Configure Firebase in the Android project and add the `google-services` plugin and `google-services.json` from your own Firebase project. Never commit private service credentials to a public repository.

## App identity
Name: VERIQUO
Package: `com.veriquo.app`
Platform: Android
Design: original premium dark interface with violet accents
