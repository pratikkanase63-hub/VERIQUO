package com.veriquo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10131B)
private val Panel = Color(0xFF1B2030)
private val Violet = Color(0xFFB7A2FF)
private val Muted = Color(0xFFA9AFC1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VeriquoApp() }
    }
}

data class Post(val user: String, val caption: String, val likes: Int, val colors: List<Color>)

@Composable
fun VeriquoApp() {
    var selected by remember { mutableStateOf("Home") }
    var liked by remember { mutableStateOf(setOf<Int>()) }
    var saved by remember { mutableStateOf(setOf<Int>()) }
    var query by remember { mutableStateOf("") }
    var newCaption by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    val posts = remember {
        listOf(
            Post("pratik.creator", "Finding beauty in every moment. ✨", 1248, listOf(Color(0xFF392B67), Color(0xFFDB8D73))),
            Post("mia.daily", "Little moments, big memories.", 892, listOf(Color(0xFF245C63), Color(0xFF9BC5A5))),
            Post("alex.frames", "Chasing the golden hour.", 2104, listOf(Color(0xFF5A3455), Color(0xFFE5A45E)))
        )
    }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Violet,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("VERIQUO", fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("YOUR WORLD. YOUR SPACE.", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        Icon(Icons.Default.FavoriteBorder, "Notifications", tint = Color.White,
                            modifier = Modifier.clickable { selected = "Notifications" })
                        Icon(Icons.Default.Send, "Messages", tint = Color.White,
                            modifier = Modifier.clickable { selected = "Messages" })
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Muted) {
                    val destinations = listOf(
                        "Home" to Icons.Default.Home,
                        "Explore" to Icons.Default.Search,
                        "Create" to Icons.Default.AddBox,
                        "Reels" to Icons.Default.PlayCircle,
                        "Profile" to Icons.Default.Person
                    )
                    destinations.forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = selected == label,
                            onClick = { selected = label; notice = "" },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Violet, selectedTextColor = Violet,
                                indicatorColor = Color(0xFF302A48), unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "Home" -> HomeScreen(posts, liked, saved,
                    onLike = { i -> liked = if (i in liked) liked - i else liked + i },
                    onSave = { i -> saved = if (i in saved) saved - i else saved + i },
                    modifier = Modifier.padding(padding))
                "Explore" -> ExploreScreen(query, { query = it }, Modifier.padding(padding))
                "Create" -> CreateScreen(newCaption, { newCaption = it }, { notice = "Post draft saved locally. Connect a backend to publish." },
                    notice, Modifier.padding(padding))
                "Reels" -> SimpleScreen("VERIQUO Reels", "Short videos and creator clips will appear here.", Modifier.padding(padding))
                "Profile" -> ProfileScreen(Modifier.padding(padding))
                "Messages" -> SimpleScreen("Messages", "Your conversations will appear here after account and chat services are connected.", Modifier.padding(padding))
                "Notifications" -> SimpleScreen("Notifications", "Likes, follows and activity will appear here.", Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun HomeScreen(posts: List<Post>, liked: Set<Int>, saved: Set<Int>, onLike: (Int) -> Unit, onSave: (Int) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Text("Stories", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 18.dp, top = 8.dp, bottom = 12.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("Your story", "Alex", "Mia", "Ryan", "Sophia").forEachIndexed { index, name ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(58.dp).background(
                            Brush.linearGradient(listOf(Violet, Color(0xFFEC9BCB))), CircleShape
                        ).padding(3.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) {
                            Text(if (index == 0) "+" else name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        }
                        Text(name, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }
            HorizontalDivider(color = Color(0xFF303544), modifier = Modifier.padding(vertical = 14.dp))
        }
        items(posts.indices.toList()) { index ->
            val post = posts[index]
            Column(Modifier.fillMaxWidth().padding(bottom = 22.dp)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).background(Violet, CircleShape), contentAlignment = Alignment.Center) {
                        Text(post.user.take(1).uppercase(), color = Ink, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.padding(start = 10.dp).weight(1f)) {
                        Text(post.user, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Suggested post · Today", color = Muted, fontSize = 10.sp)
                    }
                    Icon(Icons.Default.MoreHoriz, "More", tint = Muted)
                }
                Box(Modifier.fillMaxWidth().height(290.dp).background(Brush.linearGradient(post.colors)),
                    contentAlignment = Alignment.Center) {
                    Text("VERIQUO  ✦", color = Color.White.copy(alpha = .8f), fontSize = 25.sp, fontWeight = FontWeight.Light, letterSpacing = 4.sp)
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (index in liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Like",
                        tint = if (index in liked) Color(0xFFFF6B9A) else Color.White,
                        modifier = Modifier.clickable { onLike(index) }.size(27.dp))
                    Spacer(Modifier.width(18.dp))
                    Icon(Icons.Default.ModeComment, "Comment", tint = Color.White, modifier = Modifier.size(25.dp))
                    Spacer(Modifier.width(18.dp))
                    Icon(Icons.Default.Send, "Share", tint = Color.White, modifier = Modifier.size(23.dp))
                    Spacer(Modifier.weight(1f))
                    Icon(if (index in saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Save",
                        tint = if (index in saved) Violet else Color.White,
                        modifier = Modifier.clickable { onSave(index) }.size(25.dp))
                }
                Text("${post.likes + if (index in liked) 1 else 0} likes", fontWeight = FontWeight.Bold, fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 16.dp))
                Text(post.user + "  " + post.caption, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp))
                Text("View all comments", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp))
            }
        }
    }
}

@Composable
fun ExploreScreen(query: String, onQuery: (String) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Explore", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(query, onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search creators and topics") }, singleLine = true)
        Spacer(Modifier.height(18.dp))
        Text("Discover creators", color = Muted)
        listOf("Photography", "Travel", "Lifestyle", "Technology", "Art & design").forEach {
            Row(Modifier.fillMaxWidth().padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Tag, null, tint = Violet)
                Text(it, modifier = Modifier.padding(start = 12.dp))
            }
            HorizontalDivider(color = Color(0xFF303544))
        }
    }
}

@Composable
fun CreateScreen(caption: String, onCaption: (String) -> Unit, onSave: () -> Unit, notice: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Create a post", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.fillMaxWidth().height(180.dp).background(Panel, RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.AddPhotoAlternate, null, tint = Violet, modifier = Modifier.size(42.dp))
                Text("Media upload connects in the backend stage", color = Muted, fontSize = 11.sp)
            }
        }
        OutlinedTextField(caption, onCaption, modifier = Modifier.fillMaxWidth(), label = { Text("Write a caption") })
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth(), enabled = caption.isNotBlank()) { Text("Save draft") }
        if (notice.isNotBlank()) Text(notice, color = Violet)
    }
}

@Composable
fun ProfileScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(92.dp).background(Brush.linearGradient(listOf(Violet, Color(0xFFEC9BCB))), CircleShape), contentAlignment = Alignment.Center) {
            Text("P", color = Ink, fontSize = 36.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Text("Pratik", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("@pratik.creator", color = Muted)
        Text("Creator · Your world, your space.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
        Row(Modifier.fillMaxWidth().padding(vertical = 20.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("0", "Posts"); Stat("0", "Followers"); Stat("0", "Following")
        }
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Edit profile") }
        Spacer(Modifier.height(22.dp))
        Text("Your posts will appear here", color = Muted)
    }
}

@Composable
fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun SimpleScreen(title: String, description: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(description, color = Muted)
    }
}
